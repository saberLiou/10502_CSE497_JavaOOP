/**
 * A program to start up the ATM.
 * @author saberLiou
 */
public class Hw5_Main {
	/**
	 * @param args not used
	 */
	public static void main(String[] args) {	
		ATM theATM = new ATM();
		theATM.run();
	}
}