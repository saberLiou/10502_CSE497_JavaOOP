import javax.swing.JFrame;
/**
 * 
 * @author saberLiou
 */
public class ServerTest {
	/**
	 * @param args not used
	 */
	public static void main(String[] args) {
		Server application = new Server();
		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		application.runServer();
	}
}