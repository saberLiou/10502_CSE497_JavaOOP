import javax.swing.JFrame;
/**
 * 
 * @author saberLiou
 */
public class ClientTest {
	/**
	 * @param args not used
	 */
	public static void main(String[] args) {
		Client application;
		
		if (args.length == 0){
			application = new Client("192.168.1.102");
		}
		else{
			application = new Client(args[0]);	
		}
		
		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		application.runClient();
	}
}